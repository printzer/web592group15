<!DOCTYPE html>
<html lang="en">
<head>

  <title>Home</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<style>
.bg-1 { 
background: url(images.jpg);
	background-size:contain; /* Green */
    color: #333;
	
}
.bg-2 { 
    background-color: #E1E1F0; /* Dark Blue */
    color: #333;
	border-bottom: inset;
	
	}
.bg-5 { 
    background-color: #474e5d; /* Dark Blue */
    color: #ffffff;
	margin-bottom:8px;
	
}
.bg-3 { 
    background-color: #F3F3F3; /* White */
    color: #555555;
	border-top:5px solid #000;
	border-bottom:inset;
}
.container-fluid {
    padding-top: 70px;
    padding-bottom: 70px;
}
.navbar {
    padding-top:0;
    padding-bottom:0;
    border-radius: 0;
    margin-bottom: 0;
    font-size: 15px;
    letter-spacing: 0px;
	width:100%;	
    z-index:100;
	animation-delay:2;
	box-shadow: 4px 0 8px 0 rgba(0,0,0,0.8);
	background: #F5F5F5;
	border-bottom:solid;
}

.navbar-nav li a:hover, .navbar-nav li a:active {
    color: #F5F5F5!important;
    background-color: #333 !important;
}


.bg-4 { 
    background-color: #2f2f2f;
    color: #ffffff;
}
body {
    font: 18px "Montserrat", sans-serif;
    line-height: 1.8;
    color: #000;
}

p {font-size: 16px; color: #454545; }

.margin {margin-bottom: 45px;}

.list-group-item:first-child {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

.list-group-item:last-child {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

/* Remove border and add padding to thumbnails */
.thumbnail {
    border: solid ;
	padding-top:20px;
	padding-bottom:20px;
	border-color: #E4E4E4;
	border-radius:3%;
}

.thumbnail p {
    margin-top: 15px;
    color: #555;
}

/* Black buttons with extra padding and without rounded borders */
.btn {
    padding: 10px 20px;
    background-color: #333;
    color: #f1f1f1;
    border-radius: 10%;
    transition: .2s;
}

/* On hover, the color of .btn will transition to white with black text */
.btn:hover, .btn:focus {
    border: 1px solid #333;
    background-color: #DADADA;
    color: #000;
}
.carousel-inner img {
    -webkit-filter: grayscale(30%);
    filter: grayscale(30%); /* make all photos black and white */ 
    width: 100%;/* Set width to 100% */
    margin: auto;
	
}
.carousel-control.right, .carousel-control.left {
    background-image: none;
    color: ;
}

.carousel-indicators li {
    border-color: #FFC;
}

.carousel-indicators li.active {
    background-color: #09F;
}

.item h4 {
    font-size: 19px;
    line-height: 1.375em;
    font-weight: 400;
    font-style: italic;
    margin: 70px 0;
}

.item span {
    font-style: normal;
}

.carousel-caption h1 {
    color: #fff !important;
}

@media (max-width: 600px) {
    .carousel-caption {
        display: none; /* Hide the carousel text when the screen is less than 600 pixels wide */
    }

</style>
<body>              
<nav class="navbar navbar-default" role="navigation" data-spy="affix" data-offset-top="200">
</div>    
  <div class="container">
    <div class="navbar-header" >
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span> 
      </button>
      <a class="navbar-brand" href="#"><h5 style="color:#000"><b>(TREETREE)</b></h5></a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
         <li><a href="Product.php"><h5><span class="glyphicon glyphicon-shopping-cart"></span> product</h5></a></li>  
         <li><a href="about.php"><h5 ><span class="glyphicon glyphicon-tree-deciduous"></span> about
          </h5></a></li>
         <li><a href="we.php"> <h5 ><span class="glyphicon glyphicon-log-in"></span> Login</h5></a></li>
          <li style="background:#333;"><a href="main.php"> 
          <h5 style="color:#F8F8F8"><span class="glyphicon glyphicon-home"></span> Home</h5></a></li>
      </ul>
    </div>
  </div>
  
</nav>
<div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
      <li data-target="#myCarousel" data-slide-to="3"></li>
      <li data-target="#myCarousel" data-slide-to="4"></li>
      <li data-target="#myCarousel" data-slide-to="5"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner" role="listbox">
      <div class="item active">
        <img src="slid/cobh02a_01_PH137650.jpg" alt="Image">
        <div class="carousel-caption" >
        <h1>What you search </h1>
		  <h2>You can find it here</h2>
		  This is a web site where you can find the price of a product that allows you to know the price of your favorite product.
        </div>     
      </div>

      <div class="item">
        <img src="slid/PH138193.jpg"alt="Image">
        <div class="carousel-caption">
         <h1>What you search </h1>
		  <h2>You can find it here</h2>
		  This is a web site where you can find the price of a product that allows you to know the price of your favorite product.
        </div>      
      </div>
      
       <div class="item">
        <img src="slid/PH137947.jpg" alt="Image">
        <div class="carousel-caption">
          <h1>What you search </h1>
		  <h2>You can find it here</h2>
		  This is a web site where you can find the price of a product that allows you to know the price of your favorite product.
        </div>         
      </div>
      
       <div class="item">
        <img src="slid/PH137675.jpg"alt="Image">
        <div class="carousel-caption">
          <h1>What you search </h1>
		  <h2>You can find it here</h2>
		  This is a web site where you can find the price of a product that allows you to know the price of your favorite product.
        </div>       
      </div>
      
      <div class="item">
        <img src="slid/PH137647.jpg"alt="Image">
        <div class="carousel-caption">
           <h1>What you search </h1>
		  <h2>You can find it here</h2>
		  This is a web site where you can find the price of a product that allows you to know the price of your favorite product.
        </div>       
      </div>
       <div class="item">
        <img src="slid/H138720.jpg"alt="Image">
        <div class="carousel-caption">
        <h1>What you search </h1>
		  <h2>You can find it here</h2>
		  This is a web site where you can find the price of a product that allows you to know the price of your favorite product.
        </div>        
      </div>
       <div class="item">
        <img src="slid/PH137144 (1).jpg"alt="Image">
        <div class="carousel-caption">
           <h1>What you search </h1>
		  <h2>You can find it here</h2>
		  This is a web site where you can find the price of a product that allows you to know the price of your favorite product.
        </div> 

        </div>      
      </div>
      
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
    <div class="col-sm-12" style="padding-bottom:3px; background:#333;">
</div>
 
<div class="container-fluid bg-3 text-center">
  <h3>Where To Find Me?</h3>
  <p>Wellcome</p>
</div>  

<div class="container-fluid text-center">
  <h2>Type  Product</h2>
  <h4>What are you must</h4>
  <br>
  
  <div class="row">
    <div class="col-sm-4">
      <span style="color:#09F"><img src="icon/desk.png"></span>
      <h4><b>Computer Desk</b></h4>
      <p>You can find products here ...</p>
    </div>
    <div  class="col-sm-4">
      <span  style="color:#09F"><img src="icon/sofa.png"></span>
      <h4><b>Sofa</b></h4>
      <p>You can find products here ...</p>
    </div>
    <div class="col-sm-4">
      <span  style="color:#09F"><img src="icon/closet.png"></span>
      <h4><b>Cabinet</b></h4>
      <p>You can find products here ...</p>
    </div>
    </div>
    <br>
  <div class="row">
  <div class="col-sm-4">
      <span style="color:#09F" ><img src="icon/bed.png" width="65" height="65"></span>
      <h4><b>Bed</b></h4>
      <p>You can find products here ...</p>
    </div>

    <div class="col-sm-4">
      <span style="color:#09F"><img src="icon/television.png"></span>
      <h4><b>TV Table</b></h4>
      <p>You can find products here ...</p>
    </div>
     <div class="col-sm-4">
      <span style="color:#09F"><img src="icon/chair.png"></span>
      <h4><b>chair</b></h4>
      <p>You can find products here ...</p>
    </div>
  </div>
   <br>
   <div class="row">
  <div class="col-sm-4">
      <span style="color:#09F" ><img src="icon/office-chair.png" width="65" height="65"></span>
      <h4><b>Office Chair</b></h4>
      <p>You can find products here ...</p>
    </div>

    <div class="col-sm-4">
      <span style="color:#09F"><img src="icon/table.png" width="65" height="65"></span>
      <h4><b>Table</b></h4>
      <p>You can find products here ...</p>
    </div>
     <div class="col-sm-4">
      <span style="color:#09F"><img src="icon/dressing.png" width="65" height="65"></span>
      <h4><b>Dressing Table</b></h4>
      <p>You can find products here ...</p>
    </div>
  </div>
   <br>
</div>
<div class="container"  style="padding-top:15px"></div>
<div class="container-fluid bg-2 text-center">
  <h3>What Am I?</h3>
  <p>Lorem ipsum..</p>
  <a href="#" class="btn btn-default btn-lg">
  <span class="glyphicon glyphicon-search"></span>Search
</a>
</div>
<div class="one col-sm-11" style=" margin-bottom:15px;
 background: #F3F3F3; width:100%; text-align:center; 
 font:'Times New Roman', Times, serif; padding-bottom:20px;">
<h3>Top product</h3>
 </div>
<div class="container-fluid bg-3 text-center"> 
 <div class="row text-center"  style="margin-left:5%; margin-right:5%">
  <div class="col-sm-3">
    <div class="thumbnail">
      <img src="product/table1.jpg" alt="Paris">
      <p><strong>ชุดโต๊ะอาหาร 4 ที่นั่ง</strong></p>
      <p>ราคา 1990 บาท </p>
      <button class="btn ">See More</button>
	  
    </div>
  </div>
  <div class="col-sm-3">
    <div class="thumbnail">
      <img src="product/table6.jpg" alt="New York">
      <p><strong>เก้าอี้ไม้</strong></p>
      <p>ราคา 1,200 บาท</p>
      <button  class="btn">See More</button>
    </div>
  </div>
  <div class="col-sm-3">
    <div class="thumbnail">
      <img src="product/table-00jpg.jpg" alt="San Francisco">
      <p><strong>ชุดโต๊ะกินข้าว 6 ที่นัง</strong></p>
      <p>ราคา 4,500 บาท</p>
      <button class="btn">See More</button>
    </div>
  </div>
   <div class="col-sm-3">
    <div class="thumbnail">
      <img src="product/table9.jpg" alt="Paris">
      <p><strong>ชุดโต๊ะนั่งเล่น</strong></p>
      <p>ราคา 5,200</p>
      <button class="btn">See More</button>
    </div>
  </div>
</div>
<div class="row text-center" style="margin-left:5%; margin-right:5%">
  <div class="col-sm-3">
    <div class="thumbnail">
      <img src="product/bed11.jpg" alt="Paris">
      <p><strong>เตียงนอน 6 ฟุต</strong></p>
      <p>ราคา 11,000</p>
      <button class="btn">See More</button>
    </div>
  </div>
  <div class="col-sm-3">
    <div class="thumbnail">
      <img src="product/sofa11.jpg"> 
      <p><strong>โซฟานั่งเล่น</strong></p>
      <p>ราคา 6,700 บาท</p>
      <button class="btn">See More</button>
    </div>
  </div>
  <div class="col-sm-3">
    <div class="thumbnail">
      <img src="product/3.jpg"alt="San Francisco">
      <p><strong>โต็ะ</strong></p>
      <p style="padding-bottom:2px">ราคา 4,990  บาท</p>
      <button class="btn">See More</button>
    </div>
  </div>
   <div class="col-sm-3">
    <div class="thumbnail">
      <img src="product/table.jpg" alt="Paris">
      <p><strong>โต๊ะทำงาน</strong></p>
      <p>ราคา 8,990 บาท</p>
      <button class="btn">See More</button>
    </div>
  </div>
</div>
</div>
<div class="container">
  <h3 class="text-center">Contact</h3>
  <p class="text-center">We love our fans!</p>
  <div class="row test">
    <div class="col-md-4">
      <p>Fan? Drop a note.</p>
      <p><span class="glyphicon glyphicon-map-marker"></span>Chicago, US</p>
      <p><span class="glyphicon glyphicon-phone"></span>Phone: +00 1515151515</p>
      <p><span class="glyphicon glyphicon-envelope"></span>Email: mail@mail.com</p> 
    </div>
    <div class="col-md-8">
      <div class="row">
        <div class="col-sm-6 form-group">
          <input class="form-control" id="name" name="name" placeholder="Name" type="text" required>
        </div>
        <div class="col-sm-6 form-group">
          <input class="form-control" id="email" name="email" placeholder="Email" type="email" required>
        </div>
      </div>
      <textarea class="form-control" id="comments" name="comments" placeholder="Comment" rows="5"></textarea>
      <div class="row"  style="margin-top:10px">
      </div> 
    </div>
    <div class="col-md-12 form-group" >
          <button class="btn pull-right" type="submit">Send</button>
        </div>
  </div>
</div>
<footer class="container-fluid bg-4 text-left" style="margin-top:15px">
  <p style="margin-left:10%">Bootstrap Theme Made By <a href="https://www.w3schools.com">www.w3schools.com</a></p> 
</footer>
</body>
</html>