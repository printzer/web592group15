<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
 <title>about me</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<style>
.navbar {
    padding-top:0;
    padding-bottom:0;
    border-radius: 0;
    margin-bottom: 0;
    font-size: 15px;
    letter-spacing: 0px;
	width:100%;	
    z-index:100;
	animation-delay:2;
	box-shadow: 4px 0 8px 0 rgba(0,0,0,0.8);
	background: #F5F5F5;
	border-bottom:solid;
}

.navbar-nav li a:hover, .navbar-nav li a:active {
    color: #F5F5F5!important;
    background-color: #333 !important;
}

p {font-size: 16px; color: #454545; }

.margin {margin-bottom: 45px;}

.list-group-item:first-child {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

.list-group-item:last-child {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

/* On hover, the color of .btn will transition to white with black text */

.carousel-inner img {
    -webkit-filter: grayscale(30%);
    filter: grayscale(30%); /* make all photos black and white */ 
    width: 100%;/* Set width to 100% */
    margin: auto;
	
}
.carousel-control.right, .carousel-control.left {
    background-image: none;
    color: ;
}

.carousel-indicators li {
    border-color: #FFC;
}

.carousel-indicators li.active {
    background-color: #09F;
}

.item h4 {
    font-size: 19px;
    line-height: 1.375em;
    font-weight: 400;
    font-style: italic;
    margin: 70px 0;
}

.item span {
    font-style: normal;
}

.carousel-caption h1 {
    color: #fff !important;
}

@media (max-width: 600px) {
    .carousel-caption {
        display: none; /* Hide the carousel text when the screen is less than 600 pixels wide */
	}
</style>

<nav class="navbar navbar-default" role="navigation" data-spy="affix" data-offset-top="200">
</div>    
  <div class="container">
    <div class="navbar-header" >
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span> 
      </button>
      <a class="navbar-brand" href="#"><h5 style="color:#000"><b>(TREETREE)</b></h5></a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
         <li><a href="main.php"><h5><span class="glyphicon glyphicon-shopping-cart"></span> product</h5></a></li>  
         <li style="background:#333;"><a href="about me.php">
         <h5 style="color:#F8F8F8" ><span class="glyphicon glyphicon-tree-deciduous"></span> about</h5></a></li>
         <li><a href="we.php"> <h5 ><span class="glyphicon glyphicon-log-in"></span> Login</h5></a></li>
          <li><a href="main.php"> <h5><span class="glyphicon glyphicon-home"></span> Home</h5></a></li>
      </ul>
    </div>
  </div>
  
</nav>
<div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
      <li data-target="#myCarousel" data-slide-to="3"></li>
      <li data-target="#myCarousel" data-slide-to="4"></li>
      <li data-target="#myCarousel" data-slide-to="5"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner" role="listbox">
      <div class="item active">
        <img src="slid/cobh02a_01_PH137650.jpg" alt="Image">
        <div class="carousel-caption" >
        <h1>What you search </h1>
		  <h2>You can find it here</h2>
		  This is a web site where you can find the price of a product that allows you to know the price of your favorite product.
        </div>     
      </div>

      <div class="item">
        <img src="slid/PH138193.jpg"alt="Image">
        <div class="carousel-caption">
         <h1>What you search </h1>
		  <h2>You can find it here</h2>
		  This is a web site where you can find the price of a product that allows you to know the price of your favorite product.
        </div>      
      </div>
      
       <div class="item">
        <img src="slid/PH137947.jpg" alt="Image">
        <div class="carousel-caption">
          <h1>What you search </h1>
		  <h2>You can find it here</h2>
		  This is a web site where you can find the price of a product that allows you to know the price of your favorite product.
        </div>         
      </div>
      
       <div class="item">
        <img src="slid/PH137675.jpg"alt="Image">
        <div class="carousel-caption">
          <h1>What you search </h1>
		  <h2>You can find it here</h2>
		  This is a web site where you can find the price of a product that allows you to know the price of your favorite product.
        </div>       
      </div>
      
      <div class="item">
        <img src="slid/PH137647.jpg"alt="Image">
        <div class="carousel-caption">
           <h1>What you search </h1>
		  <h2>You can find it here</h2>
		  This is a web site where you can find the price of a product that allows you to know the price of your favorite product.
        </div>       
      </div>
       <div class="item">
        <img src="slid/H138720.jpg"alt="Image">
        <div class="carousel-caption">
        <h1>What you search </h1>
		  <h2>You can find it here</h2>
		  This is a web site where you can find the price of a product that allows you to know the price of your favorite product.
        </div>        
      </div>
       <div class="item">
        <img src="slid/PH137144 (1).jpg"alt="Image">
        <div class="carousel-caption">
           <h1>What you search </h1>
		  <h2>You can find it here</h2>
		  This is a web site where you can find the price of a product that allows you to know the price of your favorite product.
        </div> 

        </div>      
      </div>
      
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
    <div class="col-sm-12" style="padding-bottom:3px; background:#333;">
</div>

<div class="container text-center" style="padding-top:10%;">
  <h3>WE  ARE TREETREE</h3>
  <p>We have created a fictional band website. ..</p>
 <div class="row">
  <div class="col-sm-4">
    <p class="text-center"><strong>Name</strong></p><br>
    <a href="#demo" data-toggle="collapse">
      <img src="bandmember.jpg" width="200" height="200" class="img-circle person" alt="Random Name">
    </a>
    <div id="demo" class="collapse">
      <p>Guitarist and Lead Vocalist</p>
      <p>Loves long walks on the beach</p>
      <p>Member since 1988</p>
    </div>
  </div>
  <div class="col-sm-4">
    <p class="text-center"><strong>Name</strong></p><br>
    <a href="#demo2" data-toggle="collapse">
      <img src="bandmember.jpg" width="200" height="200" class="img-circle person" alt="Random Name">
    </a>
    <div id="demo2" class="collapse">
      <p>Drummer</p>
      <p>Loves drummin'</p>
      <p>Member since 1988</p>
    </div>
  </div>
  <div class="col-sm-4">
    <p class="text-center"><strong>Name</strong></p><br>
    <a href="#demo3" data-toggle="collapse">
      <img src="bandmember.jpg" width="200" height="200" class="img-circle person" alt="Random Name">
    </a>
    <div id="demo3" class="collapse">
      <p>Bass player</p>
      <p>Loves math</p>
      <p>Member since 2005</p>
    </div>
  </div>
</div>
 <div class="row">
  <div class="col-sm-6">
    <p class="text-center"><strong>Name</strong></p><br>
    <a href="#demo" data-toggle="collapse">
      <img src="bandmember.jpg"width="200" height="200" class="img-circle person" alt="Random Name">
    </a>
    <div id="demo" class="collapse">
      <p>Guitarist and Lead Vocalist</p>
      <p>Loves long walks on the beach</p>
      <p>Member since 1988</p>
    </div>
  </div>
  <div class="col-sm-6">
    <p class="text-center"><strong>Name</strong></p><br>
    <a href="#demo2" data-toggle="collapse">
      <img src="bandmember.jpg" width="200" height="200" class="img-circle person" alt="Random Name">
    </a>
    <div id="demo2" class="collapse">
      <p>Drummer</p>
      <p>Loves drummin'</p>
      <p>Member since 1988</p>
    </div>
  </div>
</div>
</div>
<footer class="container-fluid bg-4 text-left" style="margin-top:10%; background:#333; padding-top:30px; padding-bottom:30px; width:100%">
  <p style="margin-left:10%">Bootstrap Theme Made By <a href="https://www.w3schools.com">www.w3schools.com</a></p> 
</footer>
</body>
</html>
